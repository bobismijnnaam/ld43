# TEMPLE BUSINESS
Every season it happens again: time for the quarterly sacrifice! You as the Temple's handyman are responsible for gathering the ingredients for the rituals. However, you can't just walk over to the ingredients. How will the elders help you gather them?

# DIFFICULTY NOTE 
The first stage (where you only have JUMP) can be perceived as _really hard_. However, every jump that you need to make for that stage is doable! So keep trying until you start feeling the controls :)

If you genuinely think you found an edge case though, please do let me know!

# CONTROLS 
- Arrow keys for walking
- Space for jumping (when the elders deem you worthy to posess it)
- Shift for running (when the elders deem you responsible enough to use it)

# ABOUT THE GAME 
"Temple Business" was made in 48 hours by Bob Rubbens for LD43.

- @bobismijnfaam
- https://www.plusminos.nl
- bobrubbens [at] gmail [dot] com
- Source: https://github.com/bobismijnnaam/ld43

# CREDITS 
- Munro font from: http://www.tenbytwenty.com/
- Unity for their great engine and dev environment, also on Linux!
- SFXR for sound effects.
- Inkscape and GIMP for being approximately usable.
